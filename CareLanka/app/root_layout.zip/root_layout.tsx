// app/_layout.tsx  ← place this in your app/ folder root
// This is the first file Expo Router loads. It checks if the user
// is logged in and sends them to the right place automatically.

import { useEffect, useState } from "react";
import { ActivityIndicator, View } from "react-native";
import { Stack, router } from "expo-router";
import "../services/firebase";                    // initialize Firebase first
import { onAuthStateChanged } from "../services/authService";
import { useAppState } from "../state/AppState";

export default function RootLayout() {
  const { setUser } = useAppState();
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged((appUser) => {
      setUser(appUser);
      setChecking(false);
      if (appUser) {
        router.replace("/(tabs)");       // logged in → go to home tab
      } else {
        router.replace("/(auth)/login"); // not logged in → go to login
      }
    });
    return unsubscribe;
  }, []);

  if (checking) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center", backgroundColor: "#BEDBD4" }}>
        <ActivityIndicator size="large" color="#1CB8AA" />
      </View>
    );
  }

  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="(auth)"  />
      <Stack.Screen name="(tabs)"  />
    </Stack>
  );
}
